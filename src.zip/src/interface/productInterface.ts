interface IProduct {
  id?: number,
  name: string,
  amount: string,
  orderId?: number
}

export default IProduct;