export default interface ILogin {
  name: string,
  password: string
}